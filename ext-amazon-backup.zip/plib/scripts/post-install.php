<?php
// Copyright 1999-2016. Parallels IP Holdings GmbH.
pm_Context::init('backup-amazon');

pm_Settings::set('_promo_admin_home', 1);
