<?php
// Copyright 1999-2016. Parallels IP Holdings GmbH.

pm_Context::init('backup-amazon');

pm_Settings::clean();